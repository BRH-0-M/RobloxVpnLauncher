using System.Diagnostics;
using System.Text.Json;

namespace RobloxVpnLauncher;

internal sealed class AppSettings
{
    public string? RobloxPath { get; set; }
    public bool SetupComplete { get; set; }
}

internal static class AppPaths
{
    public static string DataDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RobloxVpnLauncher");

    public static string SettingsPath => Path.Combine(DataDirectory, "settings.json");

    public static AppSettings LoadSettings()
    {
        try
        {
            if (File.Exists(SettingsPath))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(SettingsPath)) ?? new AppSettings();
        }
        catch (IOException) { }
        catch (JsonException) { }
        return new AppSettings();
    }

    public static void SaveSettings(AppSettings settings)
    {
        Directory.CreateDirectory(DataDirectory);
        File.WriteAllText(SettingsPath, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
    }

    public static string? FindWarpCli()
    {
        var roots = new[]
        {
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)
        };

        var installedPath = roots
            .Where(root => !string.IsNullOrWhiteSpace(root))
            .Select(root => Path.Combine(root, "Cloudflare", "Cloudflare WARP", "warp-cli.exe"))
            .FirstOrDefault(File.Exists);
        if (installedPath is not null)
            return installedPath;

        try
        {
            var startInfo = new ProcessStartInfo("where.exe")
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            startInfo.ArgumentList.Add("warp-cli.exe");
            using var process = Process.Start(startInfo);
            if (process is null || !process.WaitForExit(1500))
                return null;
            var path = process.StandardOutput.ReadToEnd().Split('\r', '\n', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
            return path is not null && File.Exists(path) ? path : null;
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or System.ComponentModel.Win32Exception)
        {
            return null;
        }
    }

    public static string? FindRobloxPlayer()
    {
        var versions = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox", "Versions");
        if (!Directory.Exists(versions))
            return null;

        try
        {
            return Directory.GetDirectories(versions)
                .Select(directory => Path.Combine(directory, "RobloxPlayerBeta.exe"))
                .Where(File.Exists)
                .OrderByDescending(File.GetLastWriteTimeUtc)
                .FirstOrDefault();
        }
        catch (IOException) { return null; }
        catch (UnauthorizedAccessException) { return null; }
    }

    public static string? FindRobloxStoreAppId()
    {
        var powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),
            "WindowsPowerShell", "v1.0", "powershell.exe");
        if (!File.Exists(powershell))
            return null;

        const string command = "$app = Get-StartApps -Name 'Roblox*' | Where-Object { $_.Name -eq 'Roblox - Windows' } | Select-Object -First 1; if ($app) { $app.AppID }";
        try
        {
            var startInfo = new ProcessStartInfo(powershell)
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            startInfo.ArgumentList.Add("-NoProfile");
            startInfo.ArgumentList.Add("-NonInteractive");
            startInfo.ArgumentList.Add("-Command");
            startInfo.ArgumentList.Add(command);

            using var process = Process.Start(startInfo);
            if (process is null)
                return null;
            var output = process.StandardOutput.ReadToEndAsync();
            var error = process.StandardError.ReadToEndAsync();
            if (!process.WaitForExit(5000))
            {
                try { process.Kill(entireProcessTree: true); } catch (InvalidOperationException) { }
                return null;
            }
            Task.WaitAll(output, error);
            var appId = output.Result.Trim();
            return process.ExitCode == 0 && appId.Length > 0 ? "store:" + appId : null;
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or System.ComponentModel.Win32Exception)
        {
            return null;
        }
    }
}
