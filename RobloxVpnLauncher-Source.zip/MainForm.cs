using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace RobloxVpnLauncher;

internal sealed class MainForm : Form
{
    private readonly RoundedButton _actionButton = new();
    private readonly Label _status = new();
    private readonly Label _byline = new();
    private readonly Label _warpReadiness = new();
    private readonly Label _robloxReadiness = new();
    private readonly TableLayoutPanel _layout = new();
    private readonly System.Windows.Forms.Timer _monitor = new() { Interval = 1800 };
    private readonly AppSettings _settings;
    private string _warpCliPath = "";
    private string _robloxTarget = "";
    private Process? _robloxProcess;
    private CancellationTokenSource? _operationCancellation;
    private bool _connected;
    private bool _busy;
    private bool _waitingForConnection;
    private bool _allowClose;
    private bool _checkingConnection;
    private bool _automaticStartupStarted;
    private DateTime _robloxLaunchTimeUtc;
    private bool _robloxWindowWasOpened;
    private int _robloxMissingWindowChecks;

    public MainForm(StartupInfo startup)
    {
        _settings = startup.Settings;
        _robloxTarget = startup.RobloxTarget;
        _warpCliPath = AppPaths.FindWarpCli() ?? "";
        InitializeComponent();
        RefreshReadiness();
        try
        {
            if (Environment.ProcessPath is { } executable)
                Icon = Icon.ExtractAssociatedIcon(executable);
        }
        catch (ArgumentException) { }

        SetStatus("Press the button to connect automatically and launch Roblox.");
        UpdateActionButton();
        _monitor.Tick += MonitorConnection;
        _monitor.Start();
        FormClosing += HandleFormClosing;
        Shown += StartAutomatically;
    }

    private void InitializeComponent()
    {
        Text = "Roblox VPN Launcher";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(740, 370);
        MinimumSize = new Size(700, 350);
        RightToLeft = RightToLeft.No;
        RightToLeftLayout = false;
        Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        BackColor = Color.FromArgb(11, 16, 28);

        _layout.Dock = DockStyle.Fill;
        _layout.ColumnCount = 1;
        _layout.RowCount = 4;
        _layout.Padding = new Padding(24, 18, 24, 16);
        _layout.BackColor = Color.FromArgb(11, 16, 28);
        _layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        _layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
        _layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 98));
        _layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 76));
        _layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(_layout);

        var heading = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 3,
            RowCount = 1,
            RightToLeft = RightToLeft.No,
            BackColor = Color.FromArgb(11, 16, 28),
            Margin = Padding.Empty
        };
        heading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        heading.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 72));
        heading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        var logo = new RoundedPictureBox
        {
            Size = new Size(72, 72),
            SizeMode = PictureBoxSizeMode.Zoom,
            Margin = Padding.Empty,
            Image = LoadLogo(),
            CornerRadius = 16,
            BackColor = Color.FromArgb(19, 25, 40)
        };
        heading.Controls.Add(logo, 1, 0);
        _layout.Controls.Add(heading, 0, 0);

        var readiness = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            RightToLeft = RightToLeft.No,
            BackColor = Color.FromArgb(22, 30, 46),
            Padding = new Padding(8),
            Margin = new Padding(0, 4, 0, 6)
        };
        readiness.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        readiness.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        ConfigureReadinessLabel(_warpReadiness, "Cloudflare WARP");
        ConfigureReadinessLabel(_robloxReadiness, "Roblox");
        readiness.Controls.Add(_warpReadiness, 0, 0);
        readiness.Controls.Add(_robloxReadiness, 1, 0);
        _layout.Controls.Add(readiness, 0, 1);

        var actionPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 1,
            RightToLeft = RightToLeft.No,
            Margin = new Padding(0, 2, 0, 2),
            BackColor = Color.FromArgb(11, 16, 28)
        };
        actionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        actionPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        _actionButton.Text = "Quick Connect & Launch Roblox";
        _actionButton.Dock = DockStyle.Fill;
        _actionButton.Margin = new Padding(0, 8, 0, 8);
        _actionButton.BackColor = Color.FromArgb(37, 99, 235);
        _actionButton.ForeColor = Color.White;
        _actionButton.CornerRadius = 18;
        _actionButton.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        _actionButton.Click += ActionButtonClick;
        actionPanel.Controls.Add(_actionButton, 0, 0);
        _layout.Controls.Add(actionPanel, 0, 2);

        _status.Text = "Ready";
        _status.Dock = DockStyle.Fill;
        _status.Margin = new Padding(0, 0, 0, 4);
        _status.TextAlign = ContentAlignment.MiddleCenter;
        _status.ForeColor = Color.FromArgb(203, 213, 225);
        _status.AutoEllipsis = true;
        _status.RightToLeft = RightToLeft.No;

        var bottomPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            RightToLeft = RightToLeft.No,
            BackColor = Color.FromArgb(11, 16, 28),
            Margin = Padding.Empty
        };
        bottomPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        bottomPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        bottomPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 20));
        _status.Margin = Padding.Empty;
        bottomPanel.Controls.Add(_status, 0, 0);

        _byline.Text = "By:@brhom_taken";
        _byline.Dock = DockStyle.Fill;
        _byline.Margin = Padding.Empty;
        _byline.TextAlign = ContentAlignment.MiddleLeft;
        _byline.ForeColor = Color.FromArgb(100, 116, 139);
        _byline.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular);
        _byline.RightToLeft = RightToLeft.No;
        bottomPanel.Controls.Add(_byline, 0, 1);
        _layout.Controls.Add(bottomPanel, 0, 3);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        if (!OperatingSystem.IsWindowsVersionAtLeast(10, 0, 17763))
            return;

        var darkMode = 1;
        var result = DwmSetWindowAttribute(Handle, 20, ref darkMode, sizeof(int));
        if (result != 0)
            _ = DwmSetWindowAttribute(Handle, 19, ref darkMode, sizeof(int));
    }

    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int valueSize);

    private static void ConfigureReadinessLabel(Label label, string title)
    {
        label.Dock = DockStyle.Fill;
        label.Margin = new Padding(5);
        label.Padding = new Padding(6);
        label.TextAlign = ContentAlignment.MiddleCenter;
        label.RightToLeft = RightToLeft.No;
        label.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);
        label.BackColor = Color.FromArgb(30, 41, 59);
        label.ForeColor = Color.FromArgb(203, 213, 225);
        label.Text = title + "\r\nChecking...";
    }

    private void RefreshReadiness()
    {
        _warpCliPath = AppPaths.FindWarpCli() ?? "";
        SetReadiness(_warpReadiness, "Cloudflare WARP", File.Exists(_warpCliPath));
        var storeReady = _robloxTarget.StartsWith("store:", StringComparison.Ordinal) && _robloxTarget.Length > "store:".Length;
        var playerReady = File.Exists(_robloxTarget);
        SetReadiness(_robloxReadiness, "Roblox", storeReady || playerReady);
    }

    private static void SetReadiness(Label label, string title, bool ready)
    {
        label.Text = title + "\r\n" + (ready ? "Ready" : "Will install automatically");
        label.ForeColor = ready ? Color.FromArgb(74, 222, 128) : Color.FromArgb(251, 191, 36);
    }

    private async void StartAutomatically(object? sender, EventArgs e)
    {
        if (_automaticStartupStarted)
            return;
        _automaticStartupStarted = true;
        await Task.Delay(350);
        if (IsDisposed || Disposing)
            return;

        RefreshReadiness();
        if (_settings.SetupComplete)
            await ConnectAsync();
        else
            SetStatus("No sign-in required. Press the button to connect to WARP.");
    }

    private async void ActionButtonClick(object? sender, EventArgs e)
    {
        if (_waitingForConnection)
        {
            _operationCancellation?.Cancel();
            SetStatus("Cancelling connection...");
            return;
        }
        if (_busy)
            return;
        if (_connected)
            await DisconnectAsync();
        else
            await ConnectAsync();
    }

    private async Task ConnectAsync()
    {
        if (_busy)
            return;

        var operationCancellation = new CancellationTokenSource();
        _operationCancellation = operationCancellation;
        SetBusy(true);
        var connectionReady = false;
        try
        {
            ResolveRobloxTarget();
            if (!IsRobloxTargetReady())
                throw new LauncherException("Roblox was not found. Install it from Microsoft Store and try again.");
            if (!await EnsureWarpInstalledAsync())
                return;

            _warpCliPath = AppPaths.FindWarpCli() ?? "";
            if (!File.Exists(_warpCliPath))
                throw new LauncherException("Cloudflare WARP was not detected after installation. Please try again.");

            _waitingForConnection = true;
            UseWaitCursor = false;
            UpdateActionButton();
            SetStatus("Connecting to an automatic WARP location and checking the internet...");
            await WarpClient.ConnectAndVerifyAsync(_warpCliPath, SetStatus, operationCancellation.Token);
            operationCancellation.Token.ThrowIfCancellationRequested();
            _waitingForConnection = false;
            UseWaitCursor = true;
            UpdateActionButton();

            connectionReady = true;
            _connected = true;
            _settings.SetupComplete = true;
            _settings.RobloxPath = _robloxTarget;
            SaveSettings();
            TrackRoblox(FindVisibleRobloxPlayerProcess() ?? LaunchRoblox(_robloxTarget));
            if (_robloxProcess is null)
                throw new LauncherException("WARP connected, but Roblox could not be opened.");
            SetStatus("WARP connected and Roblox launched.");
        }
        catch (LauncherException ex)
        {
            SetStatus(ex.Message);
        }
        catch (OperationCanceledException)
        {
            try
            {
                if (File.Exists(_warpCliPath))
                    await WarpClient.DisconnectAsync(_warpCliPath);
            }
            catch (Exception) { }
            _connected = false;
            SetStatus("Connection cancelled. Press the button to try again.");
        }
        catch (TimeoutException)
        {
            SetStatus("WARP connection could not be verified. Check your internet connection and try again.");
        }
        catch (Win32Exception ex) when (ex.NativeErrorCode == 1223)
        {
            SetStatus("Windows approval was cancelled; Roblox was not launched.");
        }
        catch (Exception)
        {
            SetStatus("Could not connect to WARP or launch Roblox. Check your internet connection and try again.");
        }
        finally
        {
            _waitingForConnection = false;
            _operationCancellation = null;
            operationCancellation.Dispose();
            if (!connectionReady && File.Exists(_warpCliPath))
                _connected = await WarpClient.GetStateAsync(_warpCliPath) == WarpState.Connected;
            RefreshReadiness();
            SetBusy(false);
            UpdateActionButton();
        }
    }

    private async Task<bool> EnsureWarpInstalledAsync()
    {
        _warpCliPath = AppPaths.FindWarpCli() ?? "";
        if (File.Exists(_warpCliPath))
            return true;

        try
        {
            SetStatus("Installing the official free Cloudflare WARP...");
            var startInfo = new ProcessStartInfo("winget.exe")
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            startInfo.ArgumentList.Add("install");
            startInfo.ArgumentList.Add("--exact");
            startInfo.ArgumentList.Add("--id");
            startInfo.ArgumentList.Add("Cloudflare.Warp");
            startInfo.ArgumentList.Add("--source");
            startInfo.ArgumentList.Add("winget");
            startInfo.ArgumentList.Add("--silent");
            startInfo.ArgumentList.Add("--accept-package-agreements");
            startInfo.ArgumentList.Add("--accept-source-agreements");

            using var process = Process.Start(startInfo) ?? throw new InvalidOperationException();
            var stdout = process.StandardOutput.ReadToEndAsync();
            var stderr = process.StandardError.ReadToEndAsync();
            await process.WaitForExitAsync();
            await Task.WhenAll(stdout, stderr);

            var until = DateTime.UtcNow.AddSeconds(15);
            while (DateTime.UtcNow < until)
            {
                _warpCliPath = AppPaths.FindWarpCli() ?? "";
                if (File.Exists(_warpCliPath))
                    return true;
                await Task.Delay(600);
            }
        }
        catch (Win32Exception ex) when (ex.NativeErrorCode == 2)
        {
            SetStatus("Automatic installation failed; opening the official WARP download.");
        }
        catch (Exception)
        {
            _warpCliPath = AppPaths.FindWarpCli() ?? "";
            if (File.Exists(_warpCliPath))
                return true;
            SetStatus("Automatic installation failed; opening the official WARP download.");
        }

        try { Process.Start(new ProcessStartInfo("https://downloads.cloudflareclient.com/v1/download/windows/ga") { UseShellExecute = true }); }
        catch (Win32Exception) { }
        SetStatus("Install Cloudflare WARP from the official download, then press the button again. No account is required.");
        return false;
    }

    private void ResolveRobloxTarget()
    {
        if (!_robloxTarget.StartsWith("store:", StringComparison.Ordinal) && !File.Exists(_robloxTarget))
            _robloxTarget = AppPaths.FindRobloxStoreAppId() ?? AppPaths.FindRobloxPlayer() ?? "";
    }

    private bool IsRobloxTargetReady() =>
        (_robloxTarget.StartsWith("store:", StringComparison.Ordinal) && _robloxTarget.Length > "store:".Length) ||
        (File.Exists(_robloxTarget) && string.Equals(Path.GetFileName(_robloxTarget), "RobloxPlayerBeta.exe", StringComparison.OrdinalIgnoreCase));

    private static Image LoadLogo()
    {
        using var stream = System.Reflection.Assembly.GetExecutingAssembly()
            .GetManifestResourceStream("RobloxVpnLauncher.Assets.RobloxVpnLogo.png");
        if (stream is null)
            return new Bitmap(1, 1);
        using var source = Image.FromStream(stream);
        return new Bitmap(source);
    }

    private static Process? FindVisibleRobloxPlayerProcess()
    {
        foreach (var process in Process.GetProcessesByName("RobloxPlayerBeta"))
        {
            var hasWindow = false;
            try
            {
                if (!process.HasExited)
                {
                    process.Refresh();
                    hasWindow = process.MainWindowHandle != IntPtr.Zero;
                }
            }
            catch (InvalidOperationException) { }
            catch (Win32Exception) { }

            if (hasWindow)
                return process;
            process.Dispose();
        }
        return null;
    }

    private bool HasManagedRobloxWindow()
    {
        using (var player = FindVisibleRobloxPlayerProcess())
        {
            if (player is not null)
                return true;
        }

        if (_robloxProcess is null)
            return false;
        try
        {
            if (_robloxProcess.HasExited)
                return false;
            _robloxProcess.Refresh();
            return _robloxProcess.MainWindowHandle != IntPtr.Zero;
        }
        catch (InvalidOperationException) { return false; }
        catch (Win32Exception) { return false; }
    }

    private static Process? LaunchRoblox(string roblox)
    {
        if (roblox.StartsWith("store:", StringComparison.Ordinal))
            return RobloxAppLauncher.LaunchStoreApp(roblox["store:".Length..]);

        var startInfo = new ProcessStartInfo(roblox)
        {
            UseShellExecute = false,
            WorkingDirectory = Path.GetDirectoryName(roblox) ?? Environment.CurrentDirectory
        };
        return Process.Start(startInfo);
    }

    private async Task DisconnectAsync()
    {
        if (_busy)
            return;
        SetBusy(true);
        try
        {
            TryCloseRoblox();
            if (!File.Exists(_warpCliPath))
                throw new LauncherException("Cloudflare WARP is unavailable, so it cannot be disconnected.");
            SetStatus("Closing Roblox and disconnecting WARP...");
            await WarpClient.DisconnectAsync(_warpCliPath);
            _connected = false;
            SetStatus("WARP disconnected and Roblox closed.");
        }
        catch (TimeoutException)
        {
            _connected = await WarpClient.GetStateAsync(_warpCliPath) == WarpState.Connected;
            SetStatus("WARP disconnection timed out. Try again using the button.");
        }
        catch (Exception)
        {
            _connected = await WarpClient.GetStateAsync(_warpCliPath) == WarpState.Connected;
            SetStatus("Could not disconnect WARP. Try again using the button.");
        }
        finally
        {
            SetBusy(false);
            UpdateActionButton();
        }
    }

    private async void MonitorConnection(object? sender, EventArgs e)
    {
        if (_checkingConnection || _busy || !File.Exists(_warpCliPath))
            return;
        _checkingConnection = true;
        try
        {
            var state = await WarpClient.GetStateAsync(_warpCliPath);
            if (_connected && state == WarpState.Disconnected)
            {
                TryCloseRoblox();
                _connected = false;
                SetStatus("WARP disconnected; Roblox closed automatically.");
                UpdateActionButton();
            }
            else if (!_connected && state == WarpState.Connected && _settings.SetupComplete)
            {
                _connected = true;
                if (IsRobloxTargetReady())
                {
                    try
                    {
                        var alreadyOpen = FindVisibleRobloxPlayerProcess();
                        TrackRoblox(alreadyOpen ?? LaunchRoblox(_robloxTarget));
                        SetStatus(alreadyOpen is null ? "WARP connected; Roblox launched automatically." : "WARP connected; monitoring the open Roblox session.");
                    }
                    catch (Exception)
                    {
                        SetStatus("WARP connected, but Roblox could not be opened.");
                    }
                }
                else
                {
                    SetStatus("WARP is connected.");
                }
                UpdateActionButton();
            }
            else if (_connected && _robloxProcess is not null)
            {
                if (HasManagedRobloxWindow())
                {
                    _robloxWindowWasOpened = true;
                    _robloxMissingWindowChecks = 0;
                }
                else if ((_robloxWindowWasOpened && ++_robloxMissingWindowChecks >= 2) ||
                         (!_robloxWindowWasOpened && DateTime.UtcNow - _robloxLaunchTimeUtc >= TimeSpan.FromSeconds(45)))
                {
                    SetStatus("Roblox closed; disconnecting WARP automatically...");
                    await DisconnectAsync();
                }
            }
        }
        finally
        {
            _checkingConnection = false;
        }
    }

    private async void HandleFormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_allowClose)
            return;

        e.Cancel = true;
        if (_busy)
        {
            SetStatus("Cancel the connection from the button before closing the app.");
            return;
        }

        if (_connected || _robloxProcess is not null)
        {
            await DisconnectAsync();
            if (_connected)
                return;
        }

        _monitor.Stop();
        _allowClose = true;
        Close();
    }

    private void SaveSettings()
    {
        try { AppPaths.SaveSettings(_settings); }
        catch (IOException) { SetStatus("Could not save startup preferences."); }
        catch (UnauthorizedAccessException) { SetStatus("Could not save startup preferences."); }
    }

    private void SetBusy(bool busy)
    {
        _busy = busy;
        UseWaitCursor = busy;
        _actionButton.IsBusy = busy;
        UpdateActionButton();
    }

    private void UpdateActionButton()
    {
        _actionButton.Text = _waitingForConnection
            ? "Cancel Connection"
            : _connected ? "Disconnect WARP & Close Roblox" : "Quick Connect & Launch Roblox";
        _actionButton.Enabled = !_busy || _waitingForConnection;
        _actionButton.BackColor = _connected ? Color.FromArgb(185, 28, 28) : Color.FromArgb(37, 99, 235);
    }

    private void SetStatus(string message) => _status.Text = message;

    private void TryCloseRoblox()
    {
        var trackedProcess = _robloxProcess;
        _robloxProcess = null;
        _robloxWindowWasOpened = false;
        _robloxMissingWindowChecks = 0;
        if (trackedProcess is not null)
        {
            try
            {
                if (!trackedProcess.HasExited)
                    trackedProcess.Kill(entireProcessTree: true);
            }
            catch (InvalidOperationException) { }
            catch (Win32Exception) { }
            finally
            {
                trackedProcess.Dispose();
            }
        }

        foreach (var player in Process.GetProcessesByName("RobloxPlayerBeta"))
        {
            try
            {
                if (!player.HasExited)
                    player.Kill(entireProcessTree: true);
            }
            catch (InvalidOperationException) { }
            catch (Win32Exception) { }
            finally
            {
                player.Dispose();
            }
        }
    }

    private void TrackRoblox(Process? process)
    {
        _robloxProcess?.Dispose();
        _robloxProcess = process;
        _robloxLaunchTimeUtc = DateTime.UtcNow;
        _robloxMissingWindowChecks = 0;
        _robloxWindowWasOpened = process is not null && HasManagedRobloxWindow();
    }

    private sealed class LauncherException(string message) : Exception(message);
}

internal sealed class RoundedButton : Button
{
    private readonly System.Windows.Forms.Timer _animationTimer = new() { Interval = 30 };
    private bool _hovered;
    private bool _pressed;
    private bool _isBusy;
    private float _spinnerAngle;

    public int CornerRadius { get; set; } = 16;

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (_isBusy == value)
                return;
            _isBusy = value;
            if (_isBusy)
                _animationTimer.Start();
            else
                _animationTimer.Stop();
            Invalidate();
        }
    }

    public RoundedButton()
    {
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        _animationTimer.Tick += (_, _) =>
        {
            _spinnerAngle = (_spinnerAngle + 13F) % 360F;
            Invalidate();
        };
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        UpdateRoundedRegion();
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        _hovered = true;
        Invalidate();
        base.OnMouseEnter(e);
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        _hovered = false;
        _pressed = false;
        Invalidate();
        base.OnMouseLeave(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
            _pressed = true;
        Invalidate();
        base.OnMouseDown(e);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        _pressed = false;
        Invalidate();
        base.OnMouseUp(e);
    }

    protected override void OnEnabledChanged(EventArgs e)
    {
        base.OnEnabledChanged(e);
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        e.Graphics.Clear(Parent?.BackColor ?? SystemColors.Control);
        var inset = _pressed ? 3 : 1;
        var bounds = new Rectangle(inset, inset, Math.Max(1, Width - inset * 2 - 1), Math.Max(1, Height - inset * 2 - 1));
        using var path = RoundedControlGeometry.CreatePath(bounds, CornerRadius);
        var color = !Enabled ? Color.FromArgb(71, 85, 105) :
            _pressed ? ControlPaint.Dark(BackColor, 0.12F) :
            _hovered ? ControlPaint.Light(BackColor, 0.08F) : BackColor;
        using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                   bounds, color, ControlPaint.Light(color, 0.06F), System.Drawing.Drawing2D.LinearGradientMode.Horizontal))
            e.Graphics.FillPath(brush, path);

        if (_hovered && Enabled && !_pressed)
        {
            using var glow = new Pen(Color.FromArgb(95, 147, 197, 253), 2F);
            e.Graphics.DrawPath(glow, path);
        }

        if (_isBusy)
        {
            var spinner = new Rectangle(bounds.X + 18, bounds.Y + (bounds.Height - 19) / 2, 19, 19);
            using var spinnerPen = new Pen(Color.FromArgb(225, Color.White), 2.4F)
            {
                StartCap = System.Drawing.Drawing2D.LineCap.Round,
                EndCap = System.Drawing.Drawing2D.LineCap.Round
            };
            e.Graphics.DrawArc(spinnerPen, spinner, _spinnerAngle, 250F);
        }

        TextRenderer.DrawText(e.Graphics, Text, Font, bounds,
            Enabled ? ForeColor : Color.FromArgb(203, 213, 225),
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
            TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);

        if (Focused && ShowFocusCues)
        {
            using var pen = new Pen(Color.FromArgb(180, 255, 255, 255), 1.5F);
            e.Graphics.DrawPath(pen, path);
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _animationTimer.Stop();
            _animationTimer.Dispose();
        }
        base.Dispose(disposing);
    }

    private void UpdateRoundedRegion()
    {
        if (Width < 2 || Height < 2)
            return;
        using var path = RoundedControlGeometry.CreatePath(new Rectangle(0, 0, Width, Height), CornerRadius);
        var oldRegion = Region;
        Region = new Region(path);
        oldRegion?.Dispose();
    }
}

internal sealed class RoundedPictureBox : PictureBox
{
    public int CornerRadius { get; set; } = 14;

    public RoundedPictureBox()
    {
        SetStyle(ControlStyles.ResizeRedraw, true);
    }

    protected override void OnSizeChanged(EventArgs e)
    {
        base.OnSizeChanged(e);
        if (Width < 2 || Height < 2)
            return;
        using var path = RoundedControlGeometry.CreatePath(new Rectangle(0, 0, Width, Height), CornerRadius);
        var oldRegion = Region;
        Region = new Region(path);
        oldRegion?.Dispose();
    }
}

internal static class RoundedControlGeometry
{
    public static System.Drawing.Drawing2D.GraphicsPath CreatePath(Rectangle bounds, int radius)
    {
        var path = new System.Drawing.Drawing2D.GraphicsPath();
        var diameter = Math.Clamp(radius * 2, 2, Math.Min(bounds.Width, bounds.Height));
        var arc = new Rectangle(bounds.X, bounds.Y, diameter, diameter);
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.X;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }
}
