# Roblox WARP Launcher (Windows)

A free, dark Windows launcher that connects Cloudflare WARP and opens Roblox with one button. The free WARP connection does not require an account or a manually supplied VPN profile.

## How to use

1. Open the app and click **Quick Connect & Launch Roblox**.
2. If WARP is not installed, the app attempts to install the official version through Windows Package Manager.
3. It connects to WARP, verifies the tunnel, and then launches Roblox.
4. Roblox and WARP are linked: closing Roblox, including with Alt+F4, disconnects WARP; if WARP disconnects, Roblox is closed. If Roblox is already open, the app monitors that session instead of blocking startup. The main button disconnects both.

After setup, the app reconnects automatically when opened later. Windows may ask you to approve installing VPN software. WARP may ask you to accept its privacy terms on first use; there is no sign-in or account creation page.

## Speed and location

- WARP automatically selects a Cloudflare connection point. You cannot select a country or a specific Roblox server.
- WARP routes the device's network traffic, not only Roblox.
- Speed and ping can improve or worsen depending on your internet provider and route to Roblox. The app cannot guarantee a particular speed or ping.
- Free WARP does not require an account. WARP+ is optional.

## Requirements

- Windows 10 or 11, 64-bit, with an internet connection.
- Roblox installed. The app searches for it automatically.
- Keep all package files together. Requires the .NET 8 Desktop Runtime: [Download the official .NET 8 Desktop Runtime](https://dotnet.microsoft.com/en-us/download/dotnet/8.0).

If automatic installation through Windows Package Manager fails, the app opens Cloudflare's official download page. Install WARP and click the same button again.

## Build

The build requires the .NET 8 SDK:

```powershell
.\build.ps1
```

## Official links

- [Set up WARP on Windows](https://developers.cloudflare.com/warp-client/get-started/windows/)
- [Download WARP for Windows](https://downloads.cloudflareclient.com/v1/download/windows/ga)
