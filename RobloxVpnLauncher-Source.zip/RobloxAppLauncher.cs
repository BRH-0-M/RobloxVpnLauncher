using System.Diagnostics;
using System.Runtime.InteropServices;

namespace RobloxVpnLauncher;

internal static class RobloxAppLauncher
{
    [ComImport]
    [Guid("2e941141-7f97-4756-ba1d-9decde894a3d")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IApplicationActivationManager
    {
        [PreserveSig]
        int ActivateApplication(
            [MarshalAs(UnmanagedType.LPWStr)] string appUserModelId,
            [MarshalAs(UnmanagedType.LPWStr)] string? arguments,
            uint options,
            out uint processId);
    }

    [ComImport]
    [Guid("45BA127D-10A8-46EA-8AB7-56EA9078943C")]
    [ClassInterface(ClassInterfaceType.None)]
    private class ApplicationActivationManager { }

    public static Process LaunchStoreApp(string appUserModelId)
    {
        object? managerObject = null;
        try
        {
            managerObject = new ApplicationActivationManager();
            var manager = (IApplicationActivationManager)managerObject;
            var result = manager.ActivateApplication(appUserModelId, null, 0, out var processId);
            Marshal.ThrowExceptionForHR(result);
            if (processId == 0)
                throw new InvalidOperationException("Windows did not return the Roblox process ID.");
            return Process.GetProcessById((int)processId);
        }
        finally
        {
            if (managerObject is not null && Marshal.IsComObject(managerObject))
                Marshal.FinalReleaseComObject(managerObject);
        }
    }
}
