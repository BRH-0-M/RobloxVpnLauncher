using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Reflection;

namespace RobloxVpnLauncher;

internal sealed class LauncherApplicationContext : ApplicationContext
{
    private readonly SplashForm _splash;

    public LauncherApplicationContext()
    {
        _splash = new SplashForm();
        _splash.StartupFinished += StartupFinished;
        MainForm = _splash;
        _splash.Show();
    }

    private void StartupFinished(object? sender, EventArgs e)
    {
        var main = new MainForm(_splash.StartupData ?? StartupInfo.Load());
        MainForm = main;
        main.Show();
        _splash.Hide();
        _splash.Dispose();
    }
}

internal sealed class SplashForm : Form
{
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 35 };
    private readonly Task<StartupInfo> _startupTask = Task.Run(StartupInfo.Load);
    private readonly Stopwatch _clock = Stopwatch.StartNew();
    private readonly PictureBox _logo = new();
    private readonly Label _loadingLabel = new();
    private readonly Panel _progressTrack = new();
    private readonly Label _percentLabel = new();
    private double _progress;
    private int _frame;

    public event EventHandler? StartupFinished;
    public StartupInfo? StartupData { get; private set; }

    public SplashForm()
    {
        Text = "Roblox VPN Launcher";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        ControlBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(480, 370);
        BackColor = Color.FromArgb(10, 13, 20);
        ForeColor = Color.White;
        DoubleBuffered = true;

        _logo.SizeMode = PictureBoxSizeMode.Zoom;
        _logo.BackColor = Color.Transparent;
        _logo.Size = new Size(124, 124);
        _logo.Location = new Point((ClientSize.Width - _logo.Width) / 2, 35);
        _logo.Image = LoadLogo();
        Controls.Add(_logo);

        var title = new Label
        {
            Text = "ROBLOX VPN",
            Font = new Font("Segoe UI", 21F, FontStyle.Bold),
            ForeColor = Color.White,
            TextAlign = ContentAlignment.MiddleCenter,
            Location = new Point(30, 178),
            Size = new Size(420, 42)
        };
        Controls.Add(title);

        var subtitle = new Label
        {
            Text = "Preparing Cloudflare WARP to launch Roblox.",
            Font = new Font("Segoe UI", 10F, FontStyle.Regular),
            ForeColor = Color.FromArgb(150, 165, 190),
            TextAlign = ContentAlignment.MiddleCenter,
            Location = new Point(30, 220),
            Size = new Size(420, 28),
            RightToLeft = RightToLeft.No
        };
        Controls.Add(subtitle);

        _loadingLabel.Text = "Loading application";
        _loadingLabel.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);
        _loadingLabel.ForeColor = Color.FromArgb(219, 226, 239);
        _loadingLabel.TextAlign = ContentAlignment.MiddleCenter;
        _loadingLabel.Location = new Point(30, 273);
        _loadingLabel.Size = new Size(420, 28);
        _loadingLabel.RightToLeft = RightToLeft.No;
        Controls.Add(_loadingLabel);

        _progressTrack.Location = new Point(70, 312);
        _progressTrack.Size = new Size(340, 8);
        _progressTrack.BackColor = Color.FromArgb(31, 39, 54);
        _progressTrack.Paint += PaintProgress;
        Controls.Add(_progressTrack);

        _percentLabel.Text = "0%";
        _percentLabel.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular);
        _percentLabel.ForeColor = Color.FromArgb(121, 151, 201);
        _percentLabel.TextAlign = ContentAlignment.MiddleCenter;
        _percentLabel.Location = new Point(70, 327);
        _percentLabel.Size = new Size(340, 22);
        Controls.Add(_percentLabel);

        var byline = new Label
        {
            Text = "By:@brhom_taken",
            Font = new Font("Segoe UI", 8F, FontStyle.Regular),
            ForeColor = Color.FromArgb(100, 116, 139),
            TextAlign = ContentAlignment.MiddleLeft,
            Location = new Point(12, 350),
            Size = new Size(180, 16)
        };
        Controls.Add(byline);

        _timer.Tick += AnimateLoading;
        Shown += (_, _) => _timer.Start();
    }

    private static Image LoadLogo()
    {
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("RobloxVpnLauncher.Assets.RobloxVpnLogo.png");
        if (stream is null)
            return new Bitmap(1, 1);
        using var source = Image.FromStream(stream);
        return new Bitmap(source);
    }

    private void AnimateLoading(object? sender, EventArgs e)
    {
        _frame++;
        var diameter = 122 + (int)(Math.Sin(_frame * 0.09) * 5);
        _logo.Size = new Size(diameter, diameter);
        _logo.Location = new Point((ClientSize.Width - diameter) / 2, 35 + (124 - diameter) / 2);
        _loadingLabel.Text = "Loading application" + new string('.', _frame / 12 % 4);

        if (!_startupTask.IsCompleted)
            _progress = Math.Min(88, _progress + 0.75);
        else if (_clock.ElapsedMilliseconds < 1450)
            _progress = Math.Min(88, _progress + 1.2);
        else
            _progress = Math.Min(100, _progress + 4.5);

        _percentLabel.Text = $"{(int)_progress}%";
        _progressTrack.Invalidate();

        if (_progress < 100)
            return;

        _timer.Stop();
        try { StartupData = _startupTask.GetAwaiter().GetResult(); }
        catch { StartupData = new StartupInfo(AppPaths.LoadSettings(), AppPaths.FindRobloxStoreAppId() ?? AppPaths.FindRobloxPlayer() ?? ""); }
        StartupFinished?.Invoke(this, EventArgs.Empty);
    }

    private void PaintProgress(object? sender, PaintEventArgs e)
    {
        var width = (int)((_progressTrack.ClientSize.Width - 2) * (_progress / 100));
        if (width <= 0)
            return;

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var brush = new LinearGradientBrush(
            new Rectangle(0, 0, Math.Max(width, 1), _progressTrack.Height),
            Color.FromArgb(34, 105, 245), Color.FromArgb(83, 178, 255), LinearGradientMode.Horizontal);
        e.Graphics.FillRectangle(brush, 1, 1, width, _progressTrack.Height - 2);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _timer.Stop();
            _timer.Dispose();
            _logo.Image?.Dispose();
        }
        base.Dispose(disposing);
    }
}
