namespace RobloxVpnLauncher;

internal sealed record StartupInfo(AppSettings Settings, string RobloxTarget)
{
    public static StartupInfo Load()
    {
        var settings = AppPaths.LoadSettings();
        var savedRoblox = settings.RobloxPath;
        var roblox = !string.IsNullOrWhiteSpace(savedRoblox) &&
                     (savedRoblox.StartsWith("store:", StringComparison.Ordinal) || File.Exists(savedRoblox))
            ? savedRoblox
            : AppPaths.FindRobloxStoreAppId() ?? AppPaths.FindRobloxPlayer() ?? "";

        return new StartupInfo(settings, roblox);
    }
}
