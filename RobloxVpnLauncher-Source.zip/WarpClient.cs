using System.Diagnostics;
using System.Text.RegularExpressions;

namespace RobloxVpnLauncher;

internal enum WarpState
{
    Unknown,
    Disconnected,
    Connected
}

internal sealed record WarpCommandResult(int ExitCode, string Output)
{
    public WarpState State => WarpClient.ParseState(Output);
}

internal static class WarpClient
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(6) };

    public static WarpState ParseState(string output)
    {
        if (Regex.IsMatch(output, @"(?im)^\s*(?:Status update:\s*)?Connected\s*$"))
            return WarpState.Connected;
        if (Regex.IsMatch(output, @"(?im)^\s*(?:Status update:\s*)?Disconnected\s*$"))
            return WarpState.Disconnected;
        return WarpState.Unknown;
    }

    public static async Task<WarpState> GetStateAsync(string cliPath, CancellationToken cancellationToken = default)
    {
        try
        {
            return (await RunAsync(cliPath, ["status"], cancellationToken)).State;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or System.ComponentModel.Win32Exception or TimeoutException)
        {
            return WarpState.Unknown;
        }
    }

    public static async Task<bool> ConnectAndVerifyAsync(string cliPath, Action<string> status, CancellationToken cancellationToken)
    {
        var state = await GetStateAsync(cliPath, cancellationToken);
        if (state != WarpState.Connected)
        {
            status("Setting up the free WARP connection...");
            var registration = await RunAsync(cliPath, ["registration", "new"], cancellationToken);
            state = await GetStateAsync(cliPath, cancellationToken);
            if (state == WarpState.Unknown && registration.ExitCode != 0)
                throw new InvalidOperationException(UsefulOutput(registration.Output));

            var connect = await RunAsync(cliPath, ["connect"], cancellationToken);
            if (connect.ExitCode != 0 && await GetStateAsync(cliPath, cancellationToken) != WarpState.Connected)
                throw new InvalidOperationException(UsefulOutput(connect.Output));
        }

        var until = DateTime.UtcNow.AddSeconds(60);
        var nextMessage = DateTime.UtcNow.AddSeconds(5);
        while (DateTime.UtcNow < until)
        {
            cancellationToken.ThrowIfCancellationRequested();
            state = await GetStateAsync(cliPath, cancellationToken);
            if (state == WarpState.Connected && await VerifyTrafficAsync(cancellationToken))
                return true;

            if (DateTime.UtcNow >= nextMessage)
            {
                status("Waiting for WARP to confirm internet access...");
                nextMessage = DateTime.UtcNow.AddSeconds(5);
            }
            await Task.Delay(1500, cancellationToken);
        }

        throw new TimeoutException("WARP did not confirm internet access through the tunnel before the timeout.");
    }

    public static async Task<bool> VerifyTrafficAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await Http.GetAsync("https://www.cloudflare.com/cdn-cgi/trace", cancellationToken);
            response.EnsureSuccessStatusCode();
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            return Regex.IsMatch(body, @"(?m)^warp=on\s*$");
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or IOException)
        {
            return false;
        }
    }

    public static async Task DisconnectAsync(string cliPath, CancellationToken cancellationToken = default)
    {
        var result = await RunAsync(cliPath, ["disconnect"], cancellationToken);
        if (result.ExitCode != 0 && await GetStateAsync(cliPath, cancellationToken) != WarpState.Disconnected)
            throw new InvalidOperationException(UsefulOutput(result.Output));

        var until = DateTime.UtcNow.AddSeconds(20);
        while (DateTime.UtcNow < until)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var state = await GetStateAsync(cliPath, cancellationToken);
            if (state == WarpState.Disconnected)
                return;
            await Task.Delay(500, cancellationToken);
        }

        throw new TimeoutException("WARP did not disconnect before the timeout.");
    }

    public static Task<WarpCommandResult> RunAsync(string cliPath, IReadOnlyList<string> arguments, CancellationToken cancellationToken = default)
    {
        return RunAsyncCore(cliPath, arguments, cancellationToken);
    }

    private static async Task<WarpCommandResult> RunAsyncCore(string cliPath, IReadOnlyList<string> arguments, CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo(cliPath)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            WindowStyle = ProcessWindowStyle.Hidden
        };
        foreach (var argument in arguments)
            startInfo.ArgumentList.Add(argument);

        using var process = Process.Start(startInfo) ?? throw new InvalidOperationException("Could not start Cloudflare WARP.");
        var stdout = process.StandardOutput.ReadToEndAsync();
        var stderr = process.StandardError.ReadToEndAsync();
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeout.Token);
        try
        {
            await process.WaitForExitAsync(linked.Token);
        }
        catch (OperationCanceledException)
        {
            try { process.Kill(entireProcessTree: true); } catch (InvalidOperationException) { }
            if (cancellationToken.IsCancellationRequested)
                throw;
            throw new TimeoutException("Cloudflare WARP did not respond before the timeout.");
        }

        await Task.WhenAll(stdout, stderr);
        var output = (await stdout) + Environment.NewLine + (await stderr);
        return new WarpCommandResult(process.ExitCode, output.Trim());
    }

    private static string UsefulOutput(string output)
    {
        var cleaned = Regex.Replace(output, @"\s+", " ").Trim();
        return cleaned.Length > 240 ? cleaned[..240] : cleaned;
    }
}
