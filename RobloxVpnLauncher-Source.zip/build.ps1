$ErrorActionPreference = 'Stop'

dotnet publish (Join-Path $PSScriptRoot 'RobloxVpnLauncher.csproj') `
  --configuration Release `
  --output (Join-Path $PSScriptRoot 'publish')

Write-Host "Build complete: $PSScriptRoot\publish\RobloxVpnLauncher.exe"
